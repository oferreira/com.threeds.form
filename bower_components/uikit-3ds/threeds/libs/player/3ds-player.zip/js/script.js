// ***
// *
// Dependencies:
//    - jQuery
//    - jwplayer.js
//    - jquery.player3ds.js
// *
// ***

// ****
// call the plugin with standard inline script, and javascript object as configuration
function stdUse() {

	var playerOptions = {
		width: 700, // default: 640
		height: 400, // default: 360
		// autostart: true, // false by default
		sharing: {}, 	// don't put it in the options if sharing not wanted
						// default link: page's url
			   			// no embed code
		playlistUrl: "json/playlist1.json"
	}; // EO playerOptions

	$('#player').player3ds( playerOptions );

} // EO stdUse()

function initPlayerFromDOMElement( elem ) {

	var player = $( elem );
	var playerWidth = player.data( 'width' ); // data-width attribute
	var playerHeight = player.data( 'height'); // data-height attribute
	var playlistUrl = player.data( 'json' ); // data-json attribute
	var playerShare = player.data( 'share' ) !== undefined; // is true if the data-share attribute is present
	var playerAutostart = player.data( 'autostart' ) !== undefined; // is true if the data-autostart attribute is present

	var playerOptions = {

		width: playerWidth, // default: 640
		height: playerHeight, // default: 360
		playlistUrl: playlistUrl

	}; // EO playerOptions

	if ( playerShare ) {
		playerOptions.sharing = {};
	}

	if ( playerAutostart ) {
		playerOptions.autostart = true;
	}
	
	player.player3ds( playerOptions );

}

// ****
// call the plugin on all DOM elements with class 'player3ds' with value passed via DOM attributes
//    + data-width
//    + data-height
//    + data-json
//    + data-share (no value: true if present, false otherwise)
//    + data-autostart (no value: true if present, false otherwise)
function embededUse(selector) {

	var players = $( selector );

	$.each( players, function( index, elem ) {
		
		initPlayerFromDOMElement( elem );

	});

} // EO attrUse()

// ****
// call the plugin on all DOM elements with class 'player3ds-lightbox' with value passed via DOM attributes
//    + data-width
//    + data-height
//    + data-json
//    + data-share (no value: true if present, false otherwise)
//    + data-autostart (no value: true if present, false otherwise)
// and display the player defined by those attributes in a lightbox
function lightboxUse(selector) {

	var lightboxPlayers = $( selector );

	$.each( lightboxPlayers, function( index, elem ) {

		$(this).click( function(e) {

			e.preventDefault();

			// get all data attributes
			var data_width = $( this ).data( 'width' ) || 640;  // setting a default value is necessary here, so that
			 													// the dimensions can be computed for the lightbox plugin	
			var data_height = $( this ).data( 'height' ) || 360; // setting a default value is necessary here, so that
			 													 // the dimensions can be computed for the lightbox plugin
			var data_json = $( this ).data( 'json' );
			var data_share = $( this ).data( 'share' );
			var data_autostart = $( this ).data( 'autostart' );

			// create the dynamic DOM elements
			var containerLayer = $("<div>").attr("id","containerLayer");
			var videoLayer = $("<div>").attr("id","videoLayer").html("Loading the player...");
			// copy data attributes to the previously created player element ( videoLayer )
			videoLayer.data( 'width', data_width );
			videoLayer.data( 'height', data_height );
			videoLayer.data( 'json', data_json );
			videoLayer.data( 'share', data_share );
			videoLayer.data( 'autostart', data_autostart );

			// append it to the DOM so that the 3dsPlayer plugin can get it
			$('body').append( videoLayer );

			// apply player3ds plugin to it
			initPlayerFromDOMElement( videoLayer );

			// create the close layer et button
			var closeLayer = $("<div>").attr("id","closeLayer");
			var closeButton = $("<a>").attr("id","closeButton").html("<span>Close</span>");

			// apend everything to the containerLayer parent element
			containerLayer.append( videoLayer ).append(closeLayer.append(closeButton));

			// apply then the Lightbox plugin
			Lightbox.open('obj',containerLayer, null, function(){
				Lightbox.getTopLeft();
				closeButton.click(function(){
					Lightbox.close();
				});
			}, true);
			
		}); // EO $(this).click()

	}); // EO $.each( lightboxPlayers )
	
} // EO lighboxUse()


$(function() {
	// stdUse();
	selector = ".player3ds";
	embededUse(selector);
	selector = ".player3ds-lightbox";
	lightboxUse(selector);

});