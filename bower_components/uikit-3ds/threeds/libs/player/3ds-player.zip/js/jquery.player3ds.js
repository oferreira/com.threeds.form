/**************************************************************
Player 3DS 0.1.0 | 10/17/2014
Developed by: Cédric GUILLOU - cgu2@3ds.com | Dassault Systèmes
***************************************************************/

// ***
// *
// Dependencies:
//    - jQuery
//    - jwplayer.js
// *
// ***
// 


$.fn.player3ds = function( options ) {

	var thePlayer;
	var thePlayerDOMId = $(this).attr( 'id' );

	var isComplete = false; // to keep track of the current video state: false if it is playing, true if it is 
							// in a complete state, meaning call to action and / or replay block should
							// potentially be displayed


	/* ================================= */
	/* === PASSED OPTIONS' VALIDATION === */
	/* ================================= */

	function isIntParsable ( val ) {
		if ( val && (  val === 'undefined' || isNaN( parseInt( val ) ) ) ){
			return false;
		}
		return true;
	}

	// width
	// -----
	// should be an integer (or should be parsable as an integer)
	// ex: 640, "640", "640px", "640 px", ...
	
	// >> do not to it if % values are admitted
	// if ( !isIntParsable( options.width ) ){
	// 	delete options.width;
	// } else {
	// 	options.width = parseInt( options.width );
	// }

	// height
	// ------
	// should be an integer (or should be parsable as an integer)
	// ex: 360, "360", "360px", "360 px", ...
	
	// >> do not to it if % values are admitted
	// if ( !isIntParsable( options.height ) ){
	// 	delete options.height;
	// } else {
	// 	options.height = parseInt( options.height );
	// }

	// playlistUrl
	// -----------
	// should be a string
	if ( typeof ( options.playlistUrl ) != 'string' ) {
		delete options.playlistUrl;
	}

	/* === EO passed options validation === */


	var defaultOptions = {
		width: 640,
		height: 360,
		playlistUrl: "",
		listbarWidth: 200, 	// if enabled (playlist with more than one item)
							// final width value set in the get JSON playlist's callback
		captions: {
	        color: '#ffffff',
	        fontSize: 16,
	        backgroundOpacity: 0
	    },
	    displaytitle: false,
	    skin: "3dsSkin/3dsSkin.xml"
	    //sitecatalyst: {}
	    
	}; // EO defaultOptions

	var currentOptions = $.extend( {}, defaultOptions, options );

	// if the sharing has been enabled in the passed configuration object,
	// define the sharing link like so:
	// http://origin/pathname/#playerId#playlistItemId
	// ex: http://www.3ds.com/industries/aerospace-defense/resource-center/#player1#1
	// NB: playlistItemId is zero-based, and must be set in the playlist json file, via mediaid attribute
	if ( currentOptions.sharing ) {
		if(false/* TODO: si lightbox*/){
			/* TODO: construire le bon lien : une url qui, lors du share en lightbox, ouvre automatiquement la lb.*/
		}else{
			currentOptions.sharing.link = window.location.origin + window.location.pathname + window.location.search + "#" + thePlayerDOMId + "#MEDIAID";
		}
	}

	// if no json url is provided, use the inline arguments instead > data-video-ld, data-video-hd, data-video-image
	// (case of the home page's 3D Experience player)
	if ( !currentOptions.playlistUrl ) {

		var sources = [
			{
				file: currentOptions.videoLD,
				type: "video/mp4"
			}
		];
		if ( currentOptions.videoHD ) {
			sources.push(
				{
					file: currentOptions.videoHD,
					label: "HD",
					type: "video/mp4"
				}
			)
		}
		currentOptions.playlist = [
			{
				image: currentOptions.videoImage,
				sources: sources
			}
		];
		
		setTimeout(function() { playerSetup(currentOptions); }, 0);

	} else { // if ( !currentOptions.playlistUrl )

		/* ======================================= */
		/* === LOAD PLAYLIST AND SET PLAYER UP === */
		/* ======================================= */
		$.get( 
			currentOptions.playlistUrl, 
			function ( data ) {

				// choose between json playlist mode, or inline arguments 
				// (data-video-ld, data-video-hd, data-video-image) -> case of the home page's 3D Experience player
				if ( !currentOptions.playlist ) { 
					// this is the case where playlist is loaded from a json file (via data-json attribute)
					currentOptions.playlist = data;

					// prevent spaces problems in media urls by encoding urls
					for ( var i = 0; i < currentOptions.playlist.length; i++ ) { 

						currentOptions.playlist[i].image = encodeURI( currentOptions.playlist[i].image );

						for ( var j = 0; j < currentOptions.playlist[i].sources.length; j++ ) {
							currentOptions.playlist[i].sources[j].file = encodeURI( currentOptions.playlist[i].sources[j].file );
						}
					}
				} 

				playerSetup( currentOptions );
				
		
			} // $.get callback

		) // $.get	

	} // END if ( !currentOptions.playlistUrl )



	/* ========================= */
	/* === FUNCTIONS LIBRARY === */
	/* ========================= */

	function playerSetup( options ) {
		// if more than one item in the playlist
		//    + enable listbar
		//    + change width to conserve video width
		if ( options.playlist.length > 1 ) {

			options.listbar = {
				position: 'right',
				size: defaultOptions.listbarWidth
			};

			options.width += defaultOptions.listbarWidth;

		} // if ( options.playlist.length > 1 )

		// **** SET THE PLAYER UP
		// --------------------------
		// NB: the player is set up even if the file has not been loaded correctly,
		// so that it can natively display the error message 
		// "Error loading player: No playable sources found"
		thePlayer = jwplayer( thePlayerDOMId )
			.setup( options )
			.onReady( function() {

				// create the CTA block and hide it immediatly, so that it can be
				// easily dimensionned and position when needed
				createCTABlock();

				// if a specific video is defined in the url, scroll to it
				scrollToVideo();

			}) // EO jwplayer.onReady()
			.onTime( function( playObject ) {
				// catch the end of the current video just before the "complete" event is thrown
				if ( playObject.position >= playObject.duration-0.3 ) {
					thePlayer.pause( true );
					doComplete();
				}
			}) // EO jwplayer.onTime()
			.onComplete( function() {
				thePlayer.stop(); // needed to avoid escaping from fullscreen mode
				doComplete();

			}) // EO jwplayer.onComplete()
			.onPlay( function() {

				// if the video is in its "complete" state
				// a click on the play button should just replay it
				if ( isComplete ) {
					thePlayer.stop();
					thePlayer.play();
				}

				isComplete = false;

				hideCtaBlock( $( "#" + thePlayerDOMId).find( "#ctaBlock" ) );
				hideReplayBlock();

			}) // EO jwplayer.onPlay()
			.onFullscreen( function() {

				// when fullscreen mode is toggled
				
				if ( isComplete ) {

					hideCtaBlock( $( "#" + thePlayerDOMId).find( "#ctaBlock" ) );
				
					// wait till the resizing is done, so that the final dimensions are set
					setTimeout( function() {
					
						var theBody = getPlayerRootElement();

						var playerWidth = theBody.outerWidth();
						var playerHeight = theBody.outerHeight();

						// display or hide the replay block regarding the player's dimensions
						if ( playerWidth >= 800 && isComplete ) {
							displayReplayBlock();
						} else {
							hideReplayBlock();
						}

						doComplete();

					}, 200);
				}

			}); // EO jwplayer.onFullscreen()
	}

	// if a specific video ID is set in the url's hash, scroll to it
	function scrollToVideo() {

		var urlHash = window.location.hash;
		var lastHashPosition = urlHash.lastIndexOf( '#' ); // position of the last hash, defining the playlist's item id
		var hashItemId = ( lastHashPosition > 0 ) ? urlHash.substring( lastHashPosition + 1 ) : null; // the player id
		var hashPlayerId = ( lastHashPosition > 0 ) ? urlHash.substring( 1, lastHashPosition ) : urlHash.substring( 1 ); // the playlist's item id
		
		// if a player id is defined in the url hash, and that id is the id of the current player
		// scroll to it
		if ( hashPlayerId && hashPlayerId === this.id ) {

			$('html, body').animate({
		        scrollTop: this.container.offsetTop
		    }, 500);

		    if ( hashItemId ) {
				this.onPlaylist( function() {
					var thePlaylist = this.getPlaylist();
					var theItemId = null;
					// get index of the item in the Playlist's array (zero-based)
					// based on his mediaid attribute
					for ( var i = 0; i < thePlaylist.length; i++ ) {
						if ( thePlaylist[i].mediaid == hashItemId ) {
							theItemId = i;
						} 
					}
					if ( theItemId != null ) { // if item with url-hash-defined mediaid found
						// load it, and play it
						this.playlistItem( theItemId );
						if ( !this.config.autostart ) {
							// unless autostart not set
							this.stop();
						}
					}
					
				});
			}
		}

	} // EO scrollToVideo()

	function getPlayerRootElement() {

		var theBody; 

		if (thePlayer.getRenderingMode() === "html5"){
			var theBody = $( "#" + thePlayerDOMId );
		} else {
			var theBody = $( "#" + thePlayerDOMId + "_wrapper" );
		}

		return theBody;

	} // EO getPlayerRootElement

	function createCTABlock() {

		var thePlaylist = thePlayer.getPlaylist();
		var currentPlaylistIndex = thePlayer.getPlaylistIndex();
		var nextPlaylistIndex = ( ( currentPlaylistIndex + 1 ) < thePlaylist.length ) ? ( currentPlaylistIndex + 1 ) : null;
		var prevPlaylistIndex = ( currentPlaylistIndex > 0 ) ? ( currentPlaylistIndex - 1 ) : null;

		var theCTA = thePlaylist[ currentPlaylistIndex ].callToAction;

		var theBody = getPlayerRootElement();

		var playerWidth = theBody.outerWidth();
		var playerHeight = theBody.outerHeight();

		/* OVERLAY */
		var overlay = $('<div id="bg">')
			.width( playerWidth )
			.height( playerHeight )
			.css( 'background', '#333333' )
			.css( 'opacity', 0.7 )
			.css( 'position', 'absolute' )
			.css( 'z-index', '1000' );

		if (thePlayer.getRenderingMode() === "html5"){
		} else {
			overlay.css( 'top', '0' );
		}
			
		//theBody.append( overlay );

		/* BLOCK CTA */
		var ctaBlock = $('<div id="ctaBlock">');

		if ( theCTA.title ) {
			var ctaTitle = $('<h2>').text( theCTA.title );
			ctaBlock.append( ctaTitle );
		}

		if ( theCTA.description ) {
			var ctaDescription = $('<h3>').text( theCTA.description );
			ctaBlock.append( ctaDescription );
		}
		

		if ( theCTA.linkUrl && theCTA.linkName ) {
			var ctaLink = $( '<a>' ).attr( "href", theCTA.linkUrl )
				.append( $('<span>').addClass('btn-title').text( theCTA.linkName ) );

			var btnIconClass = 'icon-arrowright'; // default btn icon
			if( theCTA.btnIconClass ) { // if another one is defined in the json file
				btnIconClass = theCTA.btnIconClass;
			}
			ctaLink.append( $('<span>').addClass('btn-icon ' + btnIconClass ) );

			ctaBlock.append( ctaLink );
		}
		

		// if a previous track exists in the playlist, display the link to play it
		// if ( prevPlaylistIndex !== null ) {
		// 	var ctaPrev = $('<span>').text("prev - ").css("cursor", "pointer").click( function() {
		// 		overlay.remove();
		// 		ctaBlock.remove();
		// 		thePlayer.playlistItem( prevPlaylistIndex );
		// 	});
		// 	ctaBlock.append( ctaPrev );
		// }

		// if a next track exists in the playlist, display the link to play it
		// if ( nextPlaylistIndex !== null ) {
		// 	var ctaNext = $('<span>').text(" - next").css("cursor", "pointer").click( function() {
		// 		overlay.remove();
		// 		ctaBlock.remove();
		// 		thePlayer.playlistItem( nextPlaylistIndex );
		// 	});
		// 	ctaBlock.append( ctaNext );
		// }

		hideCtaBlock( ctaBlock );
		theBody.append( ctaBlock ); // must be appended to the DOM so that jQuery is able to get its dimensions

	} // EO createCTABlock()

	// hides the call to action block by reducing its opacity and putting it under the player
	// so that it is allways at its final dimensions and can be positionned exactly before
	// displaying it when needed
	function hideCtaBlock( ctaBlock ) {
		ctaBlock.css( "opacity", "0").css( "z-index", "-1");
	} // EO hideCtaBlock()


	// ***
	// *
	// FUNCTION displayCTA
	// display a call to action at the end of a video, if defined in the playlist item
	// *
	// ***
	function displayCTA() {

		if ( positionCtaBlock() ) {
			// display it only if the positionCtaBlock returns true,
			// meaning there is enough available room for it
			var theBody = getPlayerRootElement();
			theBody.find( "#ctaBlock" ).css( "opacity", "1" ).css( "z-index", "2000");
		}


	} // EO function displayCTA()


	function positionCtaBlock () {

		var theBody = getPlayerRootElement();

		var ctaBlock = theBody.find( '#ctaBlock' );

		var playerWidth = theBody.outerWidth();
		var playerHeight = theBody.outerHeight();

		// choose cta class regarding video size
		var ctaClass = 'cta-big';

		if ( playerWidth < 800 ) {
			ctaClass = 'cta-medium';
		}
		if ( playerWidth < 600 ) {
			ctaClass = 'cta-small';
		}

		ctaBlock.removeClass( 'cta-big' ).removeClass( 'cta-medium' ).removeClass( 'cta-small' );
		ctaBlock.addClass( ctaClass );

		var ctaBlockWidth = ctaBlock.outerWidth();
		var ctaBlockHeight = ctaBlock.outerHeight( false );
		var controlBarHeight = $( "#" + thePlayerDOMId + "_controlbar" ).height();
		var replayBlockHeight = $( "#" + thePlayerDOMId ).find( ".replayBlock" ).height();

		var availableRoom = playerHeight - controlBarHeight - replayBlockHeight;

		ctaBlock.css( 'top', (  availableRoom - ctaBlockHeight ) / 2 );
		ctaBlock.css( 'left', ( playerWidth - ctaBlockWidth ) / 2 );

		// check if there is enough room to display the call to action block with top and bottom margins (2 x 10px)
		if ( availableRoom <= ctaBlockHeight - 20 ) {  
			// if not, do not display it at all
			hideCtaBlock( ctaBlock );
			return false;
		} else {
			return true;
		}

	} // EO positionCtaBlock()

	function displayReplayBlock() {

		var theBody = getPlayerRootElement();

		$( "#" + thePlayerDOMId + "_display_button").addClass( "forceHide" );

		var thePlaylist = thePlayer.getPlaylist();
		var currentPlaylistIndex = thePlayer.getPlaylistIndex();

		if ( theBody.find( ".replayBlock").length == 0 ) {
			var replayBlock = $( '<div class="replayBlock">' )
					.append( $('<div class="replay-btn">')
						.click( function(){
								hideCtaBlock( $( "#" + thePlayerDOMId).find( "#ctaBlock" ) );
								replayBlock.remove();
							 	thePlayer.playlistItem( currentPlaylistIndex );
						}) 
					);
			theBody.append( replayBlock );
		}

	} // EO displayReplayBlock()

	function hideReplayBlock() {

		var theBody = getPlayerRootElement();
		theBody.find( ".replayBlock" ).remove();

	} // EO hideReplayBlock()


	// manages the "video complete" state
	// by displaying or hiding needed elements: Call To Action and/or replay block
	function doComplete() {

		isComplete = true;

		$( "#" + thePlayerDOMId + "_controlbar" ).addClass( 'forceDisplay' );

		var theBody = getPlayerRootElement();

		var playerWidth = theBody.outerWidth();
		var playerHeight = theBody.outerHeight();

		if ( playerWidth >= 800 ) {
			displayReplayBlock();
		}

		var thePlaylist = jwplayer().getPlaylist();
		var currentPlaylistIndex = jwplayer().getPlaylistIndex();

		if ( thePlaylist[currentPlaylistIndex].callToAction ) {
			displayCTA();
		}

	} // EO doComplete()

	return this; // for chaining purpose

} // EO plugin $.fn.player3ds